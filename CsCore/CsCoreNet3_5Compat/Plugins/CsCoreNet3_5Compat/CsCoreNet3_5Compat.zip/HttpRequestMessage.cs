﻿#if NET_2_0 || NET_2_0_SUBSET

namespace System.Net.Http {

    public class HttpRequestMessage {
        public HttpRequestMessage(HttpMethod method, Uri uri) {
            throw new NotImplementedException();
        }
    }

}

#endif